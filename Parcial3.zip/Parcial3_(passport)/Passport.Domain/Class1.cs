﻿namespace Passport.Domain
{
    public class Class1
    {

    }
}
