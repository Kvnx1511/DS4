﻿using System;

namespace Passport.Domain.Entities
{
    public class Solicitud
    {
        // Clave primaria
        public int SolicitudID { get; set; }

        // Clave foránea
        public int PersonaID { get; set; }

        // Propiedades
        public DateTime FechaSolicitud { get; set; }
        public string TipoSolicitud { get; set; } = null!;
        public string EstadoSolicitud { get; set; } = null!;

        // Propiedad que acepta valores nulos (opcional)
        public DateTime? FechaAprobacion { get; set; }

        // Propiedad de navegación (la '?' indica que puede ser nulo)
        public Persona? Persona { get; set; }

        // ⚠️ ATENCIÓN: Solo mantén esta línea si tienes una entidad Pasaporte definida. 
        // Si no la tienes, elimínala.
        // public Pasaporte? Pasaporte { get; set; } 
    }
}