﻿namespace Passport.Infrastructure
{
    public class Class1
    {

    }
}
