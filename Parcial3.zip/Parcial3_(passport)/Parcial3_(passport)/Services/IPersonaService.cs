﻿using Passport.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Passport.Web.Services
{
    public interface IPersonaService
    {
        Task<IEnumerable<Persona>> GetAllAsync();
        Task<Persona?> GetByIdAsync(int id);
        Task<int> CreateAsync(Persona persona); // devuelve id
        Task UpdateAsync(Persona persona);
        Task DeleteAsync(int id);
    }
}
