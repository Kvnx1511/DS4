﻿namespace Generadorleatorios
{
    class Program
    {
        static void Main(string[] args)
        {
            Aleatorios generador = new Aleatorios();

            Console.WriteLine("ARREGLO DE NÚMEROS NO REPETIDOS\n");

            // Pedir rango al usuario
            Console.Write("Ingrese el número mínimo: ");
            int min = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el número máximo: ");
            int max = int.Parse(Console.ReadLine());

            Console.Write("¿Cuántos números desea generar?: ");
            int cantidad = int.Parse(Console.ReadLine());

            try
            {
                int[] arreglo = generador.GenerarArregloSinRepetir(cantidad, min, max);

                Console.WriteLine($"\nArreglo de {cantidad} números aleatorios sin repetir entre {min} y {max}:");
                foreach (int n in arreglo)
                    Console.WriteLine(n);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            Console.WriteLine("Fin del programa.");
        }
    }
}
