﻿using Microsoft.EntityFrameworkCore;
using Passport.Domain.Entities;
using Passport.Infrastructure.Data;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Passport.Infrastructure.Repositories
{
    public class PersonaRepository : IPersonaRepository
    {
        private readonly PassportDbContext _context;
        public PersonaRepository(PassportDbContext context) => _context = context;

        public async Task<IEnumerable<Persona>> GetAllAsync()
            => await _context.Personas.AsNoTracking().ToListAsync();

        public async Task<Persona?> GetByIdAsync(int id)
            => await _context.Personas
                             .Include(p => p.Solicitudes)
                             .AsNoTracking()
                             .FirstOrDefaultAsync(p => p.PersonaID == id);

        public async Task AddAsync(Persona persona)
        {
            await _context.Personas.AddAsync(persona);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Persona persona)
        {
            _context.Personas.Update(persona);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var entity = await _context.Personas.FindAsync(id);
            if (entity != null)
            {
                _context.Personas.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
