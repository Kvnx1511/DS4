select * from Products

select ProductID, ProductName, UnitPrice from Products

select ProductID, ProductName, UnitPrice from Products where UnitPrice > 15

select ProductID, ProductName, UnitPrice from Products where UnitPrice >= 15 AND UnitPrice <= 50

select ProductID, ProductName, UnitPrice from Products where UnitPrice BETWEEN 15 AND 50

select ProductID, ProductName, UnitPrice from Products where NOT UnitPrice > 15

select ProductID, ProductName, UnitPrice from Products where ProductID > 15 OR UnitPrice < 10

select EmployeeID, LastName from Employees where LastName like 'D%'

select EmployeeID, LastName from Employees where LastName like '%N'

select EmployeeID, LastName, Title from Employees where Title like '%SALES%'

select EmployeeID, LastName from Employees where LastName NOT like 'D%'

select ProductID, ProductName, UnitPrice from Products order by ProductID asc

select ProductID, ProductName, UnitPrice from Products order by ProductID desc

select DISTINCT OrderID from [Order Details]

select top 5 OrderID, ProductID, Quantity from [Order Details]

select top 10 percent OrderID, ProductID, Quantity from [Order Details]

select CategoryName as [Nombre de Categoria] from Categories

select OrderID, OrderDate, ShippedDate, ShippedDate + 5 as RetrasoEnvio from Orders

select OrderID, p.ProductID, ProductName from Products p inner join [Order Details] od on p.ProductID=od.ProductID

select ProductName, CompanyName, ContactName from Products p full join Suppliers s on p.SupplierID=s.SupplierID