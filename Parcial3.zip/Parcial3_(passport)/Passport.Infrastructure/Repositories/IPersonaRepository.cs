﻿// ##################################################################
// # 1. Passport.Infrastructure.Repositories / IPersonaRepository.cs
// ##################################################################
using Passport.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Passport.Domain.Interfaces // Asumiendo que esta es la ubicación real
{
    public interface IPersonaRepository
    {
        Task<IEnumerable<Persona>> GetAllAsync();
        Task<Persona?> GetByIdAsync(int id);
        Task AddAsync(Persona persona);
        Task UpdateAsync(Persona persona);
        Task DeleteAsync(int id);
    }
}