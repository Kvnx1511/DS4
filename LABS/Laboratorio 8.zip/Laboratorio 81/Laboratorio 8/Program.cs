﻿namespace Laboratorio_8
{
    class Program
    {
        public static void Main(string[] args)
        {
            Trabajador p = new Trabajador("Josan", 22, "87654321B", 2500);
            Console.WriteLine($"Nombre: {p.Nombre}");
            Console.WriteLine($"Edad: {p.Edad}");
            Console.WriteLine($"NIF: {p.NIF}");
            Console.WriteLine($"Sueldo: {p.Sueldo}");
            Console.ReadKey();
        }
    }
}