﻿namespace Passport.Domain.Entities;

public class Pasaporte
{
    public int PasaporteID { get; set; }
    public int SolicitudID { get; set; }
    public string NumeroPasaporte { get; set; } = string.Empty;
    public DateTime FechaEmision { get; set; }
    public DateTime FechaExpiracion { get; set; }
    public string EstadoPasaporte { get; set; } = string.Empty;

    public Solicitud? Solicitud { get; set; }
}
