﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Laboratorio_14
{
    public partial class frmProductos : Form
    {
        string connectionString = @"Server=.\sqlexpress;Database=productos;Trusted_Connection=True;";
        bool nuevo;

        public frmProductos()
        {
            InitializeComponent();
        }

        private void frmProductos_Load(object sender, EventArgs e)
        {
            LimpiarCampos();
            DeshabilitarCampos();
        }

        private void tsbNuevo_Click(object sender, EventArgs e)
        {
            nuevo = true;
            HabilitarCampos();
            LimpiarCampos();
            txtId.Enabled = false; // id autoincremental
            txtNombre.Focus();
        }

        private void tsbGuardar_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                if (nuevo)
                {
                    cmd.CommandText = "INSERT INTO Laptops (Nombre, Precio, Stock) VALUES (@Nombre, @Precio, @Stock)";
                }
                else
                {
                    cmd.CommandText = "UPDATE Laptops SET Nombre=@Nombre, Precio=@Precio, Stock=@Stock WHERE Id=@Id";
                    cmd.Parameters.AddWithValue("@Id", txtId.Text);
                }

                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Precio", Convert.ToDecimal(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@Stock", Convert.ToInt32(txtStock.Text));
                cmd.ExecuteNonQuery();

                MessageBox.Show("Datos guardados correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos();
                DeshabilitarCampos();
            }
        }

        private void tsbCancelar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            DeshabilitarCampos();
        }

        private void tsbEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("Seleccione un producto antes de eliminar.");
                return;
            }

            if (MessageBox.Show("¿Está seguro de eliminar este producto?", "Confirmar", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Laptops WHERE Id=@Id", con);
                    cmd.Parameters.AddWithValue("@Id", txtId.Text);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Producto eliminado correctamente.");
                LimpiarCampos();
                DeshabilitarCampos();
            }
        }

        private void tsbBuscar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tstId.Text))
            {
                MessageBox.Show("Ingrese un ID para buscar.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Laptops WHERE Id=@Id", con);
                cmd.Parameters.AddWithValue("@Id", tstId.Text);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtId.Text = dr["Id"].ToString();
                    txtNombre.Text = dr["Nombre"].ToString();
                    txtPrecio.Text = dr["Precio"].ToString();
                    txtStock.Text = dr["Stock"].ToString();

                    HabilitarCampos();
                    nuevo = false;
                }
                else
                {
                    MessageBox.Show("Producto no encontrado.");
                }
                dr.Close();
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ------------------- Métodos auxiliares -------------------
        private void LimpiarCampos()
        {
            txtId.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            tstId.Clear();
        }

        private void HabilitarCampos()
        {
            txtNombre.Enabled = true;
            txtPrecio.Enabled = true;
            txtStock.Enabled = true;
        }

        private void DeshabilitarCampos()
        {
            txtNombre.Enabled = false;
            txtPrecio.Enabled = false;
            txtStock.Enabled = false;
        }
    }
}
