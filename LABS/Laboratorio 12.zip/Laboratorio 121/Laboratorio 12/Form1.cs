﻿using System;
using System.Windows.Forms;

namespace Laboratorio_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Botón para calcular la distancia
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Convertir los valores ingresados
                double velocidad = double.Parse(txtVelocidad.Text);
                double tiempo = double.Parse(txtTiempo.Text);

                // Calcular distancia = velocidad * tiempo
                double distancia = velocidad * tiempo;

                // Mostrar resultado
                txtDistancia.Text = distancia.ToString("0.00");
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Botón para limpiar los campos
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtVelocidad.Clear();
            txtTiempo.Clear();
            txtDistancia.Clear();
            txtVelocidad.Focus();
        }

        // Botón para salir del programa
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}