﻿using System;
namespace Laboratorio_8
{
    internal class program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Corrio la aplicacion");
            Console.ReadKey();
        }
    }
}