﻿namespace TipoDeTriangulo
{
    class Program
    {
        static void Main(string[] args)
        {
            double lado1, lado2, lado3;

            Console.WriteLine("=== CLASIFICADOR DE TRIÁNGULOS ===\n");

            Console.Write("Ingrese el primer lado: ");
            lado1 = double.Parse(Console.ReadLine());

            Console.Write("Ingrese el segundo lado: ");
            lado2 = double.Parse(Console.ReadLine());

            Console.Write("Ingrese el tercer lado: ");
            lado3 = double.Parse(Console.ReadLine());

            if (EsTrianguloValido(lado1, lado2, lado3))
            {
                Console.WriteLine("\nLos lados forman un triángulo.");

                if (lado1 == lado2 && lado2 == lado3)
                {
                    Console.WriteLine("Es un triángulo EQUILÁTERO (tres lados iguales).");
                }
                else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
                {
                    Console.WriteLine("Es un triángulo ISÓSCELES (dos lados iguales).");
                }
                else
                {
                    Console.WriteLine("Es un triángulo ESCALENO (todos los lados diferentes).");
                }
            }
            else
            {
                Console.WriteLine("Los lados ingresados NO forman un triángulo válido.");
                Console.WriteLine("Recuerda: la suma de dos lados debe ser mayor que el tercero.");
            }

            Console.WriteLine("Fin del programa.");
        }
        static bool EsTrianguloValido(double a, double b, double c)
        {
            return (a + b > c) && (a + c > b) && (b + c > a);
        }
    }
}
