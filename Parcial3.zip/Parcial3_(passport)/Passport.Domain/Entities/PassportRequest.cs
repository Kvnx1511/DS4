﻿public class PassportRequest
{
    public int Id { get; set; }
    public string ApplicantName { get; set; }
    public string Nationality { get; set; }
    public DateTime BirthDate { get; set; }
    public string DocumentNumber { get; set; }
    public DateTime RequestDate { get; set; }
    public string Status { get; set; } // Pending, InReview, Approved, Rejected, Delivered
}
