﻿namespace Laboratorio_72
{
    class Program
    {
        static void Main(string[] args)
        {
            JuegoDeDados j = new JuegoDeDados();
            j.Jugar();
        }
    }
}