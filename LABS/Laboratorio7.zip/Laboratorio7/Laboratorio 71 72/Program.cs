﻿namespace Laboratorio_71_72
{
    class Program
    {
        static void Main(string[] args)
        {
            Banco banco = new Banco();
            banco.Operar();
            banco.DepositosTotales();
            Console.ReadKey();
        }
    }
}