﻿using Microsoft.EntityFrameworkCore;
using Passport.Domain.Entities;

namespace Passport.Infrastructure.Data
{
    public class PassportDbContext : DbContext
    {
        public PassportDbContext(DbContextOptions<PassportDbContext> options)
            : base(options)
        {
        }

        // 1. Corregido: Inicialización con 'null!' para evitar CS8618 (Línea 18 y 19)
        public DbSet<Persona> Personas { get; set; } = null!;
        public DbSet<Solicitud> Solicitudes { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // 2. Corregido: Llamada necesaria al método base (Línea 25)
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Persona>(entity =>
            {
                entity.ToTable("ps_personas");
                entity.HasKey(e => e.PersonaID).HasName("PK_ps_personas");

                entity.Property(e => e.PersonaID).HasColumnName("persona_id").IsRequired();
                entity.Property(e => e.PrimerNombre).HasColumnName("nombre").IsRequired().HasMaxLength(100);
                entity.Property(e => e.PrimerApellido).HasColumnName("apellido").IsRequired().HasMaxLength(100);
                entity.Property(e => e.FechaNacimiento).HasColumnName("fecha_nacimiento").IsRequired();
                entity.Property(e => e.Genero).HasColumnName("genero").HasMaxLength(1);
                entity.Property(e => e.Nacionalidad).HasColumnName("nacionalidad").HasMaxLength(50);
                entity.Property(e => e.Direccion).HasColumnName("direccion").HasMaxLength(250);
                entity.Property(e => e.Telefono).HasColumnName("telefono").HasMaxLength(20);
                entity.Property(e => e.Email).HasColumnName("correo").HasMaxLength(100);
            });

            modelBuilder.Entity<Solicitud>(entity =>
            {
                entity.ToTable("ps_solicitudes");
                entity.HasKey(e => e.SolicitudID).HasName("PK_ps_solicitudes");

                entity.Property(e => e.SolicitudID).HasColumnName("solicitud_id").IsRequired();
                entity.Property(e => e.PersonaID).HasColumnName("persona_id").IsRequired();
                entity.Property(e => e.FechaSolicitud).HasColumnName("fecha_solicitud").IsRequired();
                entity.Property(e => e.TipoSolicitud).HasColumnName("tipo_solicitud").IsRequired().HasMaxLength(50);
                entity.Property(e => e.EstadoSolicitud).HasColumnName("estado_solicitud").IsRequired().HasMaxLength(50);

                // La sintaxis de la comilla doble ya está correcta aquí.
                entity.Property(e => e.FechaAprobacion).HasColumnName("fecha_aprobacion");

                // Configuración de la relación
                entity.HasOne(e => e.Persona)
                      .WithMany(p => p.Solicitudes)
                      .HasForeignKey(e => e.PersonaID)
                      .HasConstraintName("FK_ps_solicitudes_ps_personas")
                      .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}