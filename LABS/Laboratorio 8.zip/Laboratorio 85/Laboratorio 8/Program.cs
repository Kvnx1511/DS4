﻿namespace Laboratorio_8;
internal class Program
{
    private static void Main(string[] args)
    {
        Coordenadas misCoords = new Coordenadas(10, 15);
        misCoords.VerCoordenadas();
    }
}