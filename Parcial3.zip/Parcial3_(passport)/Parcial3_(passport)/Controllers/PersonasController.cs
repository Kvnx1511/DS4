﻿using Microsoft.AspNetCore.Mvc;
using Passport.Domain.Entities;
using Passport.Web.Services;

public class PersonasController : Controller
{
    private readonly IPersonaService _service;

    public PersonasController(IPersonaService service)
    {
        _service = service;
    }

    // GET: Personas
    public async Task<IActionResult> Index()
    {
        var personas = await _service.GetAllAsync();
        return View(personas);
    }

    // GET: Personas/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Personas/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Persona persona)
    {
        if (ModelState.IsValid)
        {
            await _service.CreateAsync(persona);
            await _service.CreateAsync(new Persona
            {
                PrimerNombre = "Kevin",
                SegundoNombre = "Andrés",
                PrimerApellido = "González",
                SegundoApellido = "López",
                FechaNacimiento = new DateTime(1995, 5, 12),
                Genero = "Masculino",
                Nacionalidad = "Panameña",
                Telefono = "6000-0000",
                Email = "perro@gnsm.com"
            });

            return RedirectToAction(nameof(Index));
        }

        return View(persona);
    }

    // GET: Personas/Edit/5
    public async Task<IActionResult> Edit(int id)
    {
        var persona = await _service.GetByIdAsync(id);
        if (persona == null)
            return NotFound();

        return View(persona);
    }

    // POST: Personas/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Persona persona)
    {
        if (id != persona.PersonaID)
            return NotFound();

        if (ModelState.IsValid)
        {
            await _service.UpdateAsync(persona);
            return RedirectToAction(nameof(Index));
        }

        return View(persona);
    }

    // GET: Personas/Delete/5
    public async Task<IActionResult> Delete(int id)
    {
        var persona = await _service.GetByIdAsync(id);
        if (persona == null)
            return NotFound();

        return View(persona);
    }

    // POST: Personas/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        await _service.DeleteAsync(id);
        return RedirectToAction(nameof(Index));
    }
}
