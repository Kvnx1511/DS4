﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Passport.Domain.Entities
{
    public class Persona
    {
        // Clave primaria
        public int PersonaID { get; set; }

        // Propiedades de la base de datos (NOT NULL por 'null!' y el mapeo del DbContext)
        public string PrimerNombre { get; set; } = null!;
        public string PrimerApellido { get; set; } = null!;
        public DateTime FechaNacimiento { get; set; }
        public string Genero { get; set; } = null!;
        public string Nacionalidad { get; set; } = null!;
        public string Direccion { get; set; } = null!;
        public string Telefono { get; set; } = null!;
        public string Email { get; set; } = null!;

        // Propiedades no mapeadas (UI/Domain logic only)
        [NotMapped]
        public string? SegundoNombre { get; set; }

        [NotMapped]
        public string? SegundoApellido { get; set; }

        // Propiedad de navegación (Colección siempre inicializada para evitar null)
        public ICollection<Solicitud> Solicitudes { get; set; } = new List<Solicitud>();
    }
}