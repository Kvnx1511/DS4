﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.MonthCalendar;

namespace Laboratorio_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Botón Calcular
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                double a = double.Parse(txtLado1.Text);
                double b = double.Parse(txtLado2.Text);
                double c = double.Parse(txtLado3.Text);

                // Verificar si forma un triángulo válido
                if ((a + b > c) && (a + c > b) && (b + c > a))
                {
                    // Calcular semiperímetro
                    double s = (a + b + c) / 2;

                    // Calcular área usando la fórmula de Herón
                    double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

                    txtSemiperimetro.Text = s.ToString("0.00");
                    txtArea.Text = area.ToString("0.00");
                }
                else
                {
                    MessageBox.Show("Los lados ingresados no forman un triángulo válido.",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese valores numéricos válidos para los lados.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // Botón Limpiar
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtLado1.Clear();
            txtLado2.Clear();
            txtLado3.Clear();
            txtSemiperimetro.Clear();
            txtArea.Clear();
            txtLado1.Focus();
        }

        // Botón Salir
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
