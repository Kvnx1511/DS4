﻿using System;
namespace Laboratorio_8
{
    internal class ClaseHijo : ClaseBase
    {
       
    }
}
