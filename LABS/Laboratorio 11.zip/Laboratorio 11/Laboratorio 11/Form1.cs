﻿using System;
using System.Windows.Forms;

namespace Laboratorio_11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClickThis_Click(object sender, EventArgs e)
        {
            lblHelloWord.Text = "Hello Word";
        }
    }
}
