﻿namespace Laboratorio_8
{
    class ClaseHijo : ClaseBase
    {

    }
}
