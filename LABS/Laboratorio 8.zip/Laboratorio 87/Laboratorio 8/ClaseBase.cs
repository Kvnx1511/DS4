﻿namespace Laboratorio_8
{
    class ClaseBase
    {
        public void test()
        {
        
        }
        public void moreTesting()
        {

        }
    }
}
