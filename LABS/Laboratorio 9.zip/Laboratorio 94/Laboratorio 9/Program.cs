﻿namespace laboratorio_9
{
    class Program
    {
        static void Main(string[] args)
        {
            Aleatorios generador = new Aleatorios();

            Console.WriteLine("CLASE ALEATORIOS");

            // Generar un solo número
            int numero = generador.GenerarNumero(1, 10);
            Console.WriteLine($"Número aleatorio entre 1 y 10: {numero}");

            // Generar un arreglo de 5 números
            int[] arreglo = generador.GenerarArreglo(5, 10, 50);

            Console.WriteLine("\nArreglo de números aleatorios entre 10 y 50:");
            foreach (int n in arreglo)
            {
                Console.WriteLine(n);
            }

            Console.WriteLine("Fin del programa.");
        }
    }
}
