using Passport.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Passport.Infrastructure.Repositories;
using Passport.Web.Services;

var builder = WebApplication.CreateBuilder(args);

// MVC
builder.Services.AddControllersWithViews();

// DbContext
builder.Services.AddDbContext<PassportDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// --- AGREGAR ESTO ---
// Repository
builder.Services.AddScoped<IPersonaRepository, PersonaRepository>();

// Service
builder.Services.AddScoped<IPersonaService, PersonaService>();
// ---------------------

var app = builder.Build();

app.MapDefaultControllerRoute();

app.Run();
