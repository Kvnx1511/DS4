﻿public class Delivery
{
    public int Id { get; set; }
    public int PassportRequestId { get; set; }
    public DateTime DeliveryDate { get; set; }
    public string DeliveredBy { get; set; }
    public PassportRequest PassportRequest { get; set; }
}
