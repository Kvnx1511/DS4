﻿using System;
using System.Windows.Forms;

namespace Laboratorio_12
{
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
            }

            // Botón para calcular el promedio
            private void btnCalcular_Click(object sender, EventArgs e)
            {
                try
                {
                    double nota1 = double.Parse(txtNota1.Text);
                    double nota2 = double.Parse(txtNota2.Text);
                    double nota3 = double.Parse(txtNota3.Text);

                    // Calcular promedio
                    double promedio = (nota1 + nota2 + nota3) / 3;

                    txtPromedio.Text = promedio.ToString("0.00");
                }
                catch (FormatException)
                {
                    MessageBox.Show("Por favor, ingrese valores numéricos válidos para las notas.",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            // Botón para limpiar los campos
            private void btnLimpiar_Click(object sender, EventArgs e)
            {
                txtNota1.Clear();
                txtNota2.Clear();
                txtNota3.Clear();
                txtPromedio.Clear();
                txtNota1.Focus();
            }

            // Botón para salir del programa
            private void btnSalir_Click(object sender, EventArgs e)
            {
                Application.Exit();
            }
        }
}