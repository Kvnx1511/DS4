﻿using System;

namespace FormaDePago
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal precio;
            string formaPago;
            string numeroCuenta = "";

            // Pedir precio del producto
            do
            {
                Console.Write("Introduce el precio del producto (valor positivo): ");
                if (!decimal.TryParse(Console.ReadLine(), out precio) || precio <= 0)
                {
                    Console.WriteLine("Error: El precio debe ser un número positivo.\n");
                }
            } while (precio <= 0);

            // Pedir forma de pago
            do
            {
                Console.Write("Introduce la forma de pago (efectivo o tarjeta): ");
                formaPago = Console.ReadLine()?.ToLower();

                if (formaPago != "efectivo" && formaPago != "tarjeta")
                {
                    Console.WriteLine("Error: Debes escribir 'efectivo' o 'tarjeta'.\n");
                }

            } while (formaPago != "efectivo" && formaPago != "tarjeta");

            // Si paga con tarjeta, pedir número de cuenta
            if (formaPago == "tarjeta")
            {
                do
                {
                    Console.Write("Introduce el número de cuenta (16 dígitos): ");
                    numeroCuenta = Console.ReadLine();

                    if (numeroCuenta.Length != 16 || !long.TryParse(numeroCuenta, out _))
                    {
                        Console.WriteLine("Error: El número de cuenta debe tener exactamente 16 dígitos numéricos.");
                    }

                } while (numeroCuenta.Length != 16 || !long.TryParse(numeroCuenta, out _));
            }

            // Mostrar resumen
            Console.WriteLine("RESUMEN DE COMPRA");
            Console.WriteLine($"Precio del producto: {precio:C}");
            Console.WriteLine($"Forma de pago: {formaPago}");

            if (formaPago == "tarjeta")
                Console.WriteLine($"Número de cuenta: {numeroCuenta}");

            Console.WriteLine("Operación completada.");
        }
    }
}
