﻿namespace Laboratorio_8
{
    interface iTemplate
    {
        public void ponerVariable(string nombre, string var);
        public void verHtml(string template);
    }
}
