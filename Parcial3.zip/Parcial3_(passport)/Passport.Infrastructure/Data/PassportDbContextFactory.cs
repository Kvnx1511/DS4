﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Passport.Domain.Entities;

namespace Passport.Infrastructure.Data
{
    // Fábrica para migraciones en tiempo de diseño
    public class PassportDbContextFactory : IDesignTimeDbContextFactory<PassportDbContext>
    {
        public PassportDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<PassportDbContext>();

            // Usa tu cadena de conexión REAL
            optionsBuilder.UseSqlServer(
                "Server=localhost;Database=passport_db;Trusted_Connection=True;TrustServerCertificate=True;"
            );

            return new PassportDbContext(optionsBuilder.Options);
        }
    }

    // Contexto principal
    public class PassportDbContext : DbContext
    {
        public PassportDbContext(DbContextOptions<PassportDbContext> options)
            : base(options)
        {
        }

        public DbSet<Persona> Personas { get; set; } = null!;
        public DbSet<Solicitud> Solicitudes { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Persona>(entity =>
            {
                entity.ToTable("ps_personas");

                entity.HasKey(e => e.PersonaID).HasName("PK_ps_personas");

                entity.Property(e => e.PersonaID).HasColumnName("persona_id");
                entity.Property(e => e.PrimerNombre).HasColumnName("nombre");
                entity.Property(e => e.PrimerApellido).HasColumnName("apellido");
                entity.Property(e => e.FechaNacimiento).HasColumnName("fecha_nacimiento");
                entity.Property(e => e.Genero).HasColumnName("genero");
                entity.Property(e => e.Nacionalidad).HasColumnName("nacionalidad");
                entity.Property(e => e.Direccion).HasColumnName("direccion");
                entity.Property(e => e.Telefono).HasColumnName("telefono");
                entity.Property(e => e.Email).HasColumnName("correo");

                // Ignorar columnas que no existen en la tabla
                entity.Ignore(e => e.SegundoNombre);
                entity.Ignore(e => e.SegundoApellido);
            });

            modelBuilder.Entity<Solicitud>(entity =>
            {
                entity.ToTable("ps_solicitudes");

                entity.HasKey(e => e.SolicitudID).HasName("PK_ps_solicitudes");

                entity.Property(e => e.SolicitudID).HasColumnName("solicitud_id");
                entity.Property(e => e.PersonaID).HasColumnName("persona_id");
                entity.Property(e => e.FechaSolicitud).HasColumnName("fecha_solicitud");
                entity.Property(e => e.TipoSolicitud).HasColumnName("tipo_solicitud");
                entity.Property(e => e.EstadoSolicitud).HasColumnName("estado_solicitud");
                entity.Property(e => e.FechaAprobacion).HasColumnName("fecha_aprobacion");

                entity.HasOne(e => e.Persona)
                      .WithMany(p => p.Solicitudes)
                      .HasForeignKey(e => e.PersonaID)
                      .HasConstraintName("FK_ps_solicitudes_ps_personas");
            });
        }
    }
}
