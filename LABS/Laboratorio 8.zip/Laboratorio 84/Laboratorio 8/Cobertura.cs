﻿namespace Laboratorio_8
{
    public class Cobertura
    {
        private double radio;

        public Cobertura(double radio)
        {
            this.radio = radio;
        }

        public double Radio
        {
            get { return radio; }
        }
    }
}
