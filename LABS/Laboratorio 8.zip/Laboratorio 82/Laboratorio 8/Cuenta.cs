﻿namespace Laboratorio_8
{
    public class Cuenta
    {
        private string idCuenta;

        public Cuenta(string prmtIdCuenta)
        {
            this.idCuenta = prmtIdCuenta;
            System.Console.WriteLine("Constructor clase base para cuenta {0}", prmtIdCuenta);
        }

        public virtual void CalcularInteres()
        {
            System.Console.WriteLine("Cuenta.CalcularIntereses() efectuado para la cuenta {0}", this.idCuenta);
        }

        public string getIdCuenta()
        {
            return this.idCuenta;
        }
    }

    public class CuentaCorriente : Cuenta
    {
        public CuentaCorriente(string prmtIdCuenta) : base(prmtIdCuenta)
        {
        }

        public override void CalcularInteres()
        {
            System.Console.WriteLine("CuentaCorriente.CalcularIntereses() efectuado para la cuenta {0}", this.getIdCuenta());
        }
    }

    public class CuentaAhorro : Cuenta
    {
        public CuentaAhorro(string prmtIdCuenta) : base(prmtIdCuenta)
        {
        }

        public override void CalcularInteres()
        {
            System.Console.WriteLine("CuentaAhorro.CalcularIntereses() efectuado para la cuenta {0}", this.getIdCuenta());
        }
    }
}