﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Laboratorio_13
{
    public partial class Form1 : Form
    {
        // Campo accesible desde toda la clase
        private readonly string connectionString = @"Server=.\sqlexpress;Database=Northwind;TrustServerCertificate=true;Integrated Security=SSPI;";

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Handler vacío: evitar poner SQL o código inválido aquí
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Probar la conexión
            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                {
                    conexion.Open();
                    MessageBox.Show("Se abrió la conexión con el servidor SQL Server y se seleccionó la base de datos", "Conexión OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                MessageBox.Show("Se cerró la conexión.", "Conexión cerrada", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al probar la conexión: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnMostrarProductos_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        /// <summary>
        /// Ejecuta un query para obtener ProductName desde dbo.Products y los muestra en listBoxProductos.
        /// </summary>
        private void LoadProducts()
        {
            listBoxProductos.Items.Clear();

            const string sql = "SELECT ProductName FROM dbo.Products ORDER BY ProductName";

            try
            {
                using (SqlConnection conexion = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(sql, conexion))
                {
                    conexion.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string nombre = reader["ProductName"]?.ToString();
                            listBoxProductos.Items.Add(nombre);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar productos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
