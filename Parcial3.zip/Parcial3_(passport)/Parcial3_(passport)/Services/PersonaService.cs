﻿using Passport.Domain.Entities;
using Passport.Infrastructure.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Passport.Web.Services
{
    public class PersonaService : IPersonaService
    {
        private readonly IPersonaRepository _repo;
        public PersonaService(IPersonaRepository repo) => _repo = repo;

        public Task<IEnumerable<Persona>> GetAllAsync() => _repo.GetAllAsync();

        public Task<Persona?> GetByIdAsync(int id) => _repo.GetByIdAsync(id);

        public async Task<int> CreateAsync(Persona persona)
        {
            await _repo.AddAsync(persona);
            return persona.PersonaID;
        }

        public Task UpdateAsync(Persona persona) => _repo.UpdateAsync(persona);

        public Task DeleteAsync(int id) => _repo.DeleteAsync(id);
    }
}
