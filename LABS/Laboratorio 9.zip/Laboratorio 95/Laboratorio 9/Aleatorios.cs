﻿namespace Generadorleatorios
{
    class Aleatorios
    {
        private Random rnd;

        public Aleatorios()
        {
            rnd = new Random();
        }

        public int GenerarNumero(int min, int max)
        {
            return rnd.Next(min, max);
        }

        public int[] GenerarArreglo(int cantidad, int min, int max)
        {
            int[] arreglo = new int[cantidad];

            for (int i = 0; i < cantidad; i++)
            {
                arreglo[i] = rnd.Next(min, max);
            }

            return arreglo;
        }

        public int[] GenerarArregloSinRepetir(int cantidad, int min, int max)
        {
            int rango = max - min;
            if (cantidad > rango)
                throw new ArgumentException("La cantidad es mayor que el rango disponible. No se pueden generar números únicos.");

            HashSet<int> numeros = new HashSet<int>();

            while (numeros.Count < cantidad)
            {
                int num = rnd.Next(min, max);
                numeros.Add(num);
            }

            int[] resultado = new int[cantidad];
            numeros.CopyTo(resultado);

            return resultado;
        }
    }
}
