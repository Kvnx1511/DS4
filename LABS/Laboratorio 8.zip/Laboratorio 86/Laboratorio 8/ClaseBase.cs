﻿using System;
namespace Laboratorio_8
{
    class ClaseBase
    {
        public void test()
        {

        }

        public static void MasTests()
        {

        }
    }
}
